# apimomoapp
Api momo app gốc, thời gian tức thời

Hướng dẫn bắt api app

https://viblo.asia/p/charles-ung-dung-cong-cu-charles-vao-kiem-thu-Qbq5Q1A45D8

Sử dụng Charles bắt api của ứng dụng trên điện thoại.

Điền các biến của api vào các dòng 13-20 trong file Database.php

Thông tin database trong file Database.php dòng 337 đến 352

//----------------------------------------------------------
/**
 * @package NOTAD API MOMO
 * @author  LÊ HỒNG SƠN : 0387654818
 * @copyright   Copyright (c) 2021, notad.net
 * @link    https://notad.net
 * @since   Version 1.0
 * @method Sell Api Lịch sử giao dịch VCB, TCB 0387654818 
 */

//----------------------------------------------------------

Cron 1 phút 1 lần vào file class.momo.php

Viết code check lời nhắn trong db hoặc,

Sử dụng api host/findid.php?tranid=magiaodich

 sẽ tự check và xác nhận có giao dịch đó hay không
 
